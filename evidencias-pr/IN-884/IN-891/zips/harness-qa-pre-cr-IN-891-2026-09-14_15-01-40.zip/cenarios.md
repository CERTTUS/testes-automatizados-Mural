# Cenários de teste — `descricao-sugestao`

> Produto: **Mural de Sugestões** (`mural`)  
> Bug: **IN-884** · Tarefa de teste: **IN-891** · Dev: **IN-887** · CR: **IN-889**  
> Base: `contexto-pr.md`  
> Stack: API · Playwright + TypeScript (web) · Manual (UI)  
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**  
> Plataforma: `web` — modalidade E2E/smoke: `automacao-playwright` (não usar `automacao-wdio`)  
> Origem: cobertura **full** desta entrega (sem `escopo.md`, sem CTs MeloQA a preservar). Todos os CTs com tag **[NOVO]**.  
> Fora de escopo: limite do **título** (2–100) e dos **comentários** (500). CLI/Putty: N/A para Mural web.

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado |
| **[NOVO]** | Cenário novo — candidato a automação |
| **[GAP]** | Ainda não automatizado |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright`  
**Prioridade:** P0 · P1 · P2

---

## 1. API

**Funcionalidade:** limite de 2000 caracteres na descrição da sugestão (`POST /sugestoes` e `PUT /sugestoes/:id`), com autenticação Bearer. Teto só na validação Joi (`trim` + `max` + `required`); coluna TEXT no banco sem teto.

### CT-API-01 — Criar sugestão com descrição no teto de 2000 caracteres

**Descrição:**  
Validar que a API aceita criar uma sugestão com descrição de exatamente 2000 caracteres (após trim) e responde sucesso. Cobre o novo teto (antes 1000).

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-api`  
**Cobre:** `POST /sugestoes` · `CriarController` · `N_DESCRICAO_SUGESTAO_MAX`  
**Pré-requisitos:** token Bearer válido; produto e pilar de gestão existentes na base de teste; demais campos obrigatórios válidos (título 2–100).

**Cenário de teste:**

```gherkin
Cenário: Aceitar criação com descrição de 2000 caracteres
  Dado estar autenticado com token Bearer válido
  E ter produto e pilar de gestão válidos
  Quando enviar POST /sugestoes com descrição de 2000 caracteres e demais campos obrigatórios preenchidos
  Então retornar HTTP 201
  E persistir a sugestão com a descrição enviada
```

---

### CT-API-02 — Recusar criação com descrição de 2001 caracteres

**Descrição:**  
Validar o teto da descrição no criar: 2001 caracteres devem ser rejeitados com a mensagem de limite. Este caso não passa pela UI (`maxLength` impede digitar o 2001º).

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-api`  
**Cobre:** `POST /sugestoes` · Joi `string.max`  
**Pré-requisitos:** token Bearer válido; produto e pilar de gestão válidos.

**Cenário de teste:**

```gherkin
Cenário: Recusar criação com descrição acima do limite
  Dado estar autenticado com token Bearer válido
  E ter produto e pilar de gestão válidos
  Quando enviar POST /sugestoes com descrição de 2001 caracteres e demais campos obrigatórios preenchidos
  Então retornar HTTP 400
  E retornar body com erro verdadeiro e mensagem "A descrição deve ter no máximo 2000 caracteres."
```

---

### CT-API-03 — Recusar criação com descrição só de espaços

**Descrição:**  
Validar que descrição vazia após trim (string só com espaços, equivalente a vazia) é rejeitada. Joi aplica `trim` antes de `required`/`empty`.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-api`  
**Cobre:** `POST /sugestoes` · Joi `string.empty`  
**Pré-requisitos:** token Bearer válido; produto e pilar de gestão válidos.

**Cenário de teste:**

```gherkin
Cenário: Recusar criação com descrição vazia após trim
  Dado estar autenticado com token Bearer válido
  E ter produto e pilar de gestão válidos
  Quando enviar POST /sugestoes com descrição contendo apenas espaços e demais campos obrigatórios preenchidos
  Então retornar HTTP 400
  E retornar body com erro verdadeiro e mensagem "A descrição não pode estar vazia."
```

---

### CT-API-04 — Recusar criação sem o campo descrição

**Descrição:**  
Validar a mensagem distinta quando o campo descrição está ausente do corpo (não é o mesmo texto de “vazia”).

**Tag:** [NOVO]  
**Prioridade:** P1  
**Modalidade:** `automacao-api`  
**Cobre:** `POST /sugestoes` · Joi `any.required`  
**Pré-requisitos:** token Bearer válido; produto e pilar de gestão válidos.

**Cenário de teste:**

```gherkin
Cenário: Recusar criação sem o campo descrição
  Dado estar autenticado com token Bearer válido
  E ter produto e pilar de gestão válidos
  Quando enviar POST /sugestoes sem o campo descrição e com demais campos obrigatórios preenchidos
  Então retornar HTTP 400
  E retornar body com erro verdadeiro e mensagem "A descrição é obrigatória."
```

---

### CT-API-05 — Atualizar sugestão com descrição no teto de 2000 caracteres

**Descrição:**  
Validar que o mesmo teto de 2000 vale no atualizar, com HTTP 200. PUT exige os campos obrigatórios do contrato de atualização (incluindo situação).

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-api`  
**Cobre:** `PUT /sugestoes/:id` · `AtualizarController`  
**Pré-requisitos:** token Bearer do autor (sugestão pendente) ou de admin; sugestão existente; produto, pilar e situação válidos no body.

**Cenário de teste:**

```gherkin
Cenário: Aceitar atualização com descrição de 2000 caracteres
  Dado estar autenticado com token Bearer autorizado a editar a sugestão
  E existir uma sugestão editável na base de teste
  Quando enviar PUT /sugestoes/:id com descrição de 2000 caracteres e demais campos obrigatórios preenchidos
  Então retornar HTTP 200
  E persistir a descrição atualizada
```

---

### CT-API-06 — Recusar atualização com descrição de 2001 caracteres

**Descrição:**  
Validar o teto também no verbo de atualização: 2001 caracteres devem retornar 400 com a mesma mensagem de limite.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-api`  
**Cobre:** `PUT /sugestoes/:id` · Joi `string.max`  
**Pré-requisitos:** token Bearer autorizado; sugestão existente e editável.

**Cenário de teste:**

```gherkin
Cenário: Recusar atualização com descrição acima do limite
  Dado estar autenticado com token Bearer autorizado a editar a sugestão
  E existir uma sugestão editável na base de teste
  Quando enviar PUT /sugestoes/:id com descrição de 2001 caracteres e demais campos obrigatórios preenchidos
  Então retornar HTTP 400
  E retornar body com erro verdadeiro e mensagem "A descrição deve ter no máximo 2000 caracteres."
```

---

## 2. Smoke automatizado

> Recorte **rápido** do módulo (não suíte inteira). Prefixo `CT-SMK-…`.

**Funcionalidade:** mural autenticado, listagem e formulário de nova sugestão com contador `n/2000`.

### CT-SMK-01 — Abrir o mural autenticado e ver a listagem

**Descrição:**  
Validar que, após a entrega, o mural abre autenticado e a listagem de sugestões é exibida sem erro.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** tela inicial do mural · listagem (`SuggestionCard`)  
**Pré-requisitos:** usuário autenticado; ambiente com pelo menos uma sugestão visível.
**meloqaId:** 1f7c1b14-5e56-490f-9edb-72cabf2f722a

**Cenário de teste:**

```gherkin
Cenário: Smoke da listagem do mural
  Dado estar autenticado no Mural de Sugestões
  Quando acessar a tela inicial do mural
  Então exibir a listagem de sugestões sem erro
```

---

### CT-SMK-02 — Abrir nova sugestão e ver o contador 0/2000

**Descrição:**  
Validar que o formulário de nova sugestão abre e o contador da descrição inicia em `0/2000`.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** botão Nova Sugestão · formulário Nova sugestão (`ModalLateralSugestao`) · contador `{n}/2000`  
**Pré-requisitos:** usuário autenticado.
**meloqaId:** 360af11c-2871-4593-9524-e6579fce68bf

**Cenário de teste:**

```gherkin
Cenário: Smoke do contador no formulário de nova sugestão
  Dado estar autenticado no Mural de Sugestões
  Quando acionar Nova Sugestão
  Então exibir o formulário Nova sugestão
  E exibir o contador da descrição como 0/2000
```

---

## 3. E2E — Caminho feliz

> Fluxos UI **completos**. Modalidade `automacao-playwright`. Prefixo `CT-E2E-…`.

**Funcionalidade:** criar/editar descrição longa, contador, preview Ver mais/Ver menos e detalhes com texto completo.

### CT-E2E-01 — Criar sugestão longa e ver Ver mais no card

**Descrição:**  
Validar o fluxo de criar com descrição longa (~1800 caracteres): contador `1800/2000`, toast de sucesso e card na listagem com botão Ver mais (overflow visual de 2 linhas).

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** formulário Nova sugestão · `POST /sugestoes` (via UI) · toast de sucesso · card da listagem  
**Pré-requisitos:** usuário autenticado; produto e pilar de gestão selecionáveis; título válido.
**meloqaId:** 759604b3-2ad4-48f3-b9f0-91ee8c6cc4d2

**Cenário de teste:**

```gherkin
Cenário: Criar sugestão com descrição longa e preview com Ver mais
  Dado estar autenticado no Mural de Sugestões
  E estar no formulário Nova sugestão
  Quando preencher título, produto e pilar de gestão
  E preencher a descrição com cerca de 1800 caracteres
  Então exibir o contador da descrição como 1800/2000
  Quando acionar Enviar sugestão
  Então exibir o toast "Sugestão criada com sucesso!"
  E exibir o card da sugestão na listagem com o botão Ver mais
```

---

### CT-E2E-02 — Expandir e recolher a descrição no card sem abrir detalhes

**Descrição:**  
Validar que Ver mais expande o texto no próprio card e não abre o diálogo de detalhes; Ver menos recolhe o preview. O clique no botão não deve propagar para o card.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** preview expandível no card da listagem (`DescricaoExpandivel` em `SuggestionCard`)  
**Pré-requisitos:** usuário autenticado; sugestão visível na listagem com descrição que ultrapassa 2 linhas (ex.: a criada em CT-E2E-01).
**meloqaId:** c2886bd6-22c4-4505-b2bf-4cac06b1b520

**Cenário de teste:**

```gherkin
Cenário: Expandir e recolher a descrição no card
  Dado estar autenticado no Mural de Sugestões
  E existir na listagem um card com descrição longa e botão Ver mais
  Quando acionar Ver mais no card
  Então expandir a descrição no próprio card
  E não abrir o diálogo de detalhes da sugestão
  E exibir o botão Ver menos
  Quando acionar Ver menos
  Então recolher a descrição no preview
  E permanecer o botão Ver mais
  E não abrir o diálogo de detalhes da sugestão
```

---

### CT-E2E-03 — Abrir detalhes pelo clique no card e ver o texto completo

**Descrição:**  
Validar que o clique no card fora de Ver mais/Ver menos abre o diálogo de detalhes com a descrição completa (sem corte de 2 linhas).

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** clique no card da listagem · diálogo de detalhes (`SuggestionDetailsDialog`)  
**Pré-requisitos:** usuário autenticado; card com descrição longa visível.
**meloqaId:** 60b09d15-8086-4b5f-af34-30eeb892c64f

**Cenário de teste:**

```gherkin
Cenário: Abrir detalhes pelo clique no card
  Dado estar autenticado no Mural de Sugestões
  E existir na listagem um card com descrição longa
  Quando acionar a área do card fora do botão Ver mais
  Então abrir o diálogo de detalhes da sugestão
  E exibir a descrição completa no diálogo
```

---

### CT-E2E-04 — Editar descrição até 2000 com contador vermelho e salvar

**Descrição:**  
Validar a edição até o teto: contador `2000/2000` em vermelho, salvar com sucesso e toast de atualização.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** formulário Editar sugestão · contador vermelho no teto · `PUT /sugestoes/:id` (via UI)  
**Pré-requisitos:** usuário autenticado autor da sugestão em situação pendente, ou admin; sugestão editável com descrição já longa ou editável até 2000.
**meloqaId:** b14e2210-22fc-459d-baf6-0a79dd4cecd9

**Cenário de teste:**

```gherkin
Cenário: Editar descrição até o teto e salvar
  Dado estar autenticado com permissão para editar a sugestão
  E estar no formulário Editar sugestão
  Quando preencher a descrição com 2000 caracteres
  Então exibir o contador da descrição como 2000/2000
  E exibir o contador em vermelho
  Quando acionar Salvar alterações
  Então exibir o toast "Sugestão atualizada com sucesso!"
```

---

### CT-E2E-05 — Descrição curta sem botão Ver mais

**Descrição:**  
Validar que descrição que cabe em até 2 linhas no card não exibe Ver mais.

**Tag:** [NOVO]  
**Prioridade:** P1  
**Modalidade:** `automacao-playwright`  
**Cobre:** preview no card da listagem (descrição curta)  
**Pré-requisitos:** usuário autenticado; sugestão visível cuja descrição cabe em até 2 linhas no card (criar na própria suíte com texto curto, se necessário).
**meloqaId:** 59fe1dad-694b-4d4e-95ce-5259f354c2ef

**Cenário de teste:**

```gherkin
Cenário: Não exibir Ver mais em descrição curta
  Dado estar autenticado no Mural de Sugestões
  E existir na listagem um card com descrição curta que cabe em até duas linhas
  Quando visualizar o card
  Então não exibir o botão Ver mais
```

---

### CT-E2E-06 — Ver mais no carrossel Minhas Sugestões

**Descrição:**  
Validar a mesma expansão inline na superfície do carrossel Minhas Sugestões (não só na listagem). Clique em Ver mais não abre o diálogo de detalhes.

**Tag:** [NOVO]  
**Prioridade:** P1  
**Modalidade:** `automacao-playwright`  
**Cobre:** carrossel Minhas Sugestões (`FeaturedCards`) · preview expandível  
**Pré-requisitos:** usuário autenticado autor de uma sugestão com descrição longa o suficiente para overflow de 2 linhas no card do carrossel.
**meloqaId:** e88dd6c1-3f09-4605-b410-6b86a1c9a44d

**Cenário de teste:**

```gherkin
Cenário: Expandir descrição no carrossel Minhas Sugestões
  Dado estar autenticado no Mural de Sugestões
  E existir no carrossel Minhas Sugestões um card com descrição longa e botão Ver mais
  Quando acionar Ver mais nesse card
  Então expandir a descrição no próprio card do carrossel
  E não abrir o diálogo de detalhes da sugestão
```

---

## 4. E2E — Caminho negativo

**Funcionalidade:** bloqueios na UI — campos obrigatórios e `maxLength` 2000. O caso 2001 via API já está na seção 1; a UI não deixa digitar o 2001º caractere.

> Nota: o toast `"Faça login para enviar uma sugestão."` existe no código do formulário, mas o botão Nova Sugestão só aparece autenticado e o formulário não renderiza sem usuário. Não há CT E2E para esse toast (fluxo não alcançável pela UI atual).

### CT-E2E-07 — Recusar envio com descrição em branco

**Descrição:**  
Validar que, com título, produto e pilar preenchidos e descrição vazia (ou só espaços), a UI avisa os obrigatórios e não cria a sugestão.

**Tag:** [NOVO]  
**Prioridade:** P0  
**Modalidade:** `automacao-playwright`  
**Cobre:** formulário Nova sugestão · validação local antes do POST  
**Pré-requisitos:** usuário autenticado.
**meloqaId:** bc4cc42a-25ff-4d07-bc48-8a536b3f3f6e

**Cenário de teste:**

```gherkin
Cenário: Impedir criação com descrição em branco
  Dado estar autenticado no Mural de Sugestões
  E estar no formulário Nova sugestão
  Quando preencher título, produto e pilar de gestão
  E deixar a descrição em branco
  E acionar Enviar sugestão
  Então exibir o toast "Preencha todos os campos obrigatórios."
  E não criar uma nova sugestão
```

---

### CT-E2E-08 — Impedir o 2001º caractere no campo descrição

**Descrição:**  
Validar que a UI corta a digitação no teto: o campo não aceita o 2001º caractere e o contador permanece `2000/2000`.

**Tag:** [NOVO]  
**Prioridade:** P1  
**Modalidade:** `automacao-playwright`  
**Cobre:** campo Descrição do formulário · `maxLength` 2000  
**Pré-requisitos:** usuário autenticado; formulário Nova sugestão ou Editar sugestão aberto.
**meloqaId:** ae3de9b1-4502-4bbb-bd9e-6ccd8f7ac111

**Cenário de teste:**

```gherkin
Cenário: Não aceitar mais de 2000 caracteres na descrição
  Dado estar autenticado no Mural de Sugestões
  E estar no formulário de sugestão
  Quando preencher a descrição com 2000 caracteres
  E tentar inserir mais um caractere no campo descrição
  Então permanecer a descrição com 2000 caracteres
  E exibir o contador da descrição como 2000/2000
```

---

## 5. Manual (somente UI)

> Somente passos pela interface. Sem API/CLI/SQL. Apenas o que exige olho humano: overflow é **altura visual** (2 linhas), não contagem de caracteres.  
> CLI/Putty: **N/A** (Mural web).

### CT-MAN-01 — Conferir o corte visual de duas linhas no card

**Descrição:**  
Validar no viewport real que o preview da listagem mostra no máximo duas linhas quando a descrição transborda, antes de acionar Ver mais. Automação pode checar a existência do botão; o “são exatamente duas linhas” é visual.

**Tag:** [NOVO]  
**Prioridade:** P2  
**Modalidade:** `manual`  
**Cobre:** preview de duas linhas no card da listagem  
**Pré-requisitos:** usuário autenticado; sugestão com descrição longa visível na listagem (viewport desktop típico).
**meloqaId:** 704ca53e-a514-4afd-9fe5-8cff7b436866

**Cenário de teste:**

```gherkin
Cenário: Conferir o preview de duas linhas na listagem
  Dado estar autenticado no Mural de Sugestões
  E existir na listagem um card com descrição longa e botão Ver mais
  Quando observar o texto da descrição no card antes de acionar Ver mais
  Então exibir no máximo duas linhas de descrição
  E não cortar o título nem sobrepor o botão Ver mais
```

---

## Aprovação

> Cenários **aprovados** em 2026-09-14. CTs E2E/Smoke/Manual publicados no MeloQA e anexados em **IN-898**. Os 6 CTs de API ficam só na bateria local (não vão ao MeloQA).  
> Timer da fase `cenarios` **fechado**. Ciclo MeloQA: **na-execucao** (abre só na suíte, não agora).
