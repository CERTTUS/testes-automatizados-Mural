# Seletores (testID / data-testid) — `descricao-sugestao`

> Plataforma: `web`  
> Status: `aguardando-aprovacao`  
> História: **IN-884** · Teste: **IN-891**  
> Data: 2026-09-14

Instrumentação da UI **antes** de escrever specs. Só `data-testid` (web). Sem mudança de lógica, estilo ou texto.

Percorrido no Playwright MCP em `http://localhost:8080` (sessão admin `AC`, login local). Fonte: `mural-web`.

## Convenção do repositório

- web: atributo `data-testid` (CSS `[data-testid="…"]`)
- Preferência: `data-testid` → `aria-label` → `role`

## Inventário

| CT | Elemento (negócio) | Atributo | Valor do ID | Arquivo do produto | Confirmado no MCP | Status |
|----|--------------------|----------|-------------|--------------------|-------------------|--------|
| CT-SMK-01 | botão Nova Sugestão | `data-testid` | `btn-nova-sugestao` | `src/components/Header.tsx` | sim | adicionado |
| CT-SMK-01 | listagem Todas as Sugestões | `data-testid` | `listagem-sugestoes` | `src/pages/Index.tsx` | sim | adicionado |
| CT-SMK-01 | card da listagem | `data-testid` | `suggestion-card` | `src/components/SuggestionCard.tsx` | sim | adicionado |
| CT-SMK-01 | título do card | `data-testid` | `suggestion-card-titulo` | `src/components/SuggestionCard.tsx` | sim | adicionado |
| login | formulário de e-mail | `data-testid` | `form-login` | `src/pages/Login.tsx` | sim (tela disponível; sessão já autenticada) | adicionado |
| login | campo e-mail | `data-testid` | `input-login-email` | `src/pages/Login.tsx` | sim | adicionado |
| login | botão Entrar | `data-testid` | `btn-login-entrar` | `src/pages/Login.tsx` | sim | adicionado |
| CT-SMK-02 / E2E | formulário criar/editar | `data-testid` | `form-upsert-sugestao` | `src/components/ModalLateralSugestao.tsx` | sim | adicionado |
| CT-SMK-02 | título | `data-testid` | `input-titulo-sugestao` | `src/components/ModalLateralSugestao.tsx` | sim | adicionado |
| CT-SMK-02 | descrição | `data-testid` | `textarea-descricao-sugestao` | `src/components/ModalLateralSugestao.tsx` | sim | adicionado |
| CT-SMK-02 | contador n/2000 | `data-testid` | `contador-descricao-sugestao` | `src/components/ModalLateralSugestao.tsx` | sim (`0/2000`, `1800/2000`, `2000/2000` vermelho) | adicionado |
| E2E-01 | select Produto | `data-testid` | `produto` | `src/components/ui/select-modal.tsx` | sim | adicionado |
| E2E-01 | select Pilar | `data-testid` | `pilarGestao` | `src/components/ui/select-modal.tsx` | sim | adicionado |
| E2E-01 | Enviar sugestão | `data-testid` | `btn-enviar-sugestao` | `src/components/ModalLateralDireito.tsx` | sim | adicionado |
| E2E-04 | Salvar alterações | `data-testid` | `btn-salvar-sugestao` | `src/components/ModalLateralDireito.tsx` | sim | adicionado |
| E2E-01/02 | preview da descrição | `data-testid` | `descricao-expandivel` / `descricao-preview` | `src/components/DescricaoExpandivel.tsx` | sim | adicionado |
| E2E-02/06 | Ver mais / Ver menos | `data-testid` | `btn-descricao-toggle` | `src/components/DescricaoExpandivel.tsx` | sim (expande sem dialog; recolhe) | adicionado |
| E2E-04 | menu ⋯ do card | `data-testid` | `btn-card-menu` | `src/components/SuggestionCard.tsx` | sim | adicionado |
| E2E-04 | item Editar | `data-testid` | `menu-editar-sugestao` | `src/components/SuggestionCard.tsx` | sim | adicionado |
| E2E-03 | diálogo de detalhes | `data-testid` | `dialog-detalhes-sugestao` | `src/components/SuggestionDetailsDialog.tsx` | sim (texto completo 1800) | adicionado |
| E2E-03 | descrição completa | `data-testid` | `dialog-descricao-completa` | `src/components/SuggestionDetailsDialog.tsx` | sim | adicionado |
| E2E-04 | lápis no diálogo | `data-testid` | `btn-dialog-editar` | `src/components/SuggestionDetailsDialog.tsx` | sim | adicionado |
| E2E-06 | carrossel Minhas Sugestões | `data-testid` | `carousel-minhas-sugestoes` | `src/components/FeaturedCards.tsx` | sim | adicionado |
| E2E-06 | card do carrossel | `data-testid` | `featured-card` | `src/components/FeaturedCards.tsx` | sim | adicionado |
| — | carrossel implementadas | `data-testid` | `carousel-implementadas` | `src/components/FeaturedCards.tsx` | sim | adicionado |

## Arquivos de produto alterados (somente IDs)

- `src/pages/Login.tsx` — `form-login`, `input-login-email`, `btn-login-entrar`
- `src/components/Header.tsx` — `btn-nova-sugestao`
- `src/components/DescricaoExpandivel.tsx` — `descricao-expandivel`, `descricao-preview`, `btn-descricao-toggle`
- `src/components/SuggestionCard.tsx` — `suggestion-card`, `suggestion-card-titulo`, `btn-card-menu`, `menu-editar-sugestao`
- `src/components/ModalLateralSugestao.tsx` — `form-upsert-sugestao`, `input-titulo-sugestao`, `textarea-descricao-sugestao`, `contador-descricao-sugestao`; `cChave` do rodapé para o testid
- `src/components/ModalLateralDireito.tsx` — `btn-{cChave}` no botão de rodapé
- `src/components/ui/select-modal.tsx` — `data-testid={cId}` no trigger
- `src/components/FeaturedCards.tsx` — `carousel-implementadas`, `carousel-minhas-sugestoes`, `featured-card`
- `src/pages/Index.tsx` — `listagem-sugestoes`
- `src/components/SuggestionDetailsDialog.tsx` — `dialog-detalhes-sugestao`, `dialog-descricao-completa`, `btn-dialog-editar`

## Lacunas (sem ID estável)

- Toasts do `react-toastify` — texto visível (`Sugestão criada com sucesso!`, `Preencha todos os campos obrigatórios.`).
- MultiSelect de situação na FilterBar — rótulo `Em revisão` / `Todas as situações` (sem testid; não é o bug desta entrega).
- Campo buscar — placeholder `Buscar sugestões...`.

## CTs sem interação de UI nesta fase

- CT-API-01 a CT-API-06 — API (bateria local)
- CT-MAN-01 — manual visual (duas linhas); automação cobre só a existência do botão Ver mais

> Aguarda aprovação humana antes de tratar `seletores.md` como fechado. Specs já escritos em cima destes IDs confirmados no MCP.
