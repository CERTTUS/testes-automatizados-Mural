# Resumo da implementação — `descricao-sugestao`

> Plataforma: **web** (Playwright + TypeScript)  
> História: **IN-884** · Teste: **IN-891**  
> Data: 2026-09-14  
> MCP: Playwright (`user-Playwright`) — fluxo percorrido em `http://localhost:8080`

## Plataforma e modo

- `web` · `e2e-completo` (API + smoke + E2E feliz + E2E negativo)
- CT-MAN-01 permanece manual (corte visual de duas linhas)

## Testes criados

| Arquivo | CTs |
|---------|-----|
| `tests/e2e/specs/descricao-sugestao/api.spec.ts` | CT-API-01 … CT-API-06 |
| `tests/e2e/specs/descricao-sugestao/smoke.spec.ts` | CT-SMK-01, CT-SMK-02 |
| `tests/e2e/specs/descricao-sugestao/e2e-feliz.spec.ts` | CT-E2E-01 … CT-E2E-06 |
| `tests/e2e/specs/descricao-sugestao/e2e-negativo.spec.ts` | CT-E2E-07, CT-E2E-08 |

Page objects: `tests/e2e/pages/LoginPage.ts`, `MuralPage.ts`, `FormularioSugestaoPage.ts`.  
Helpers: `tests/e2e/helpers/env.ts`, `api.ts`.  
Catálogo: `scripts/pre-cr/catalogo-modulos.json` (slug `descricao-sugestao`).

## O que cada teste faz

### API

- **CT-API-01:** autentica no `dev-login`, cria sugestão com descrição de 2000 caracteres, espera HTTP 201 e persiste o texto.
- **CT-API-02:** cria com 2001 caracteres; espera 400 e a mensagem de teto.
- **CT-API-03:** descrição só com espaços; espera 400 “não pode estar vazia”.
- **CT-API-04:** omite o campo descrição; espera 400 “é obrigatória”.
- **CT-API-05:** cria uma sugestão e atualiza a descrição para 2000; espera HTTP 200.
- **CT-API-06:** PUT com 2001 caracteres; espera 400 e a mesma mensagem de teto.

### Smoke

- **CT-SMK-01:** entra no mural autenticado e vê pelo menos um card na listagem.
- **CT-SMK-02:** abre Nova Sugestão e confere o contador `0/2000`.

### E2E feliz

- **CT-E2E-01:** preenche título, produto, pilar e ~1800 caracteres; confere o contador; envia; espera toast de sucesso e **Ver mais** no card da listagem (filtro “Todas as situações”, porque admin cria em **Postado**).
- **CT-E2E-02:** Ver mais expande no card, não abre detalhes; Ver menos recolhe.
- **CT-E2E-03:** clique no título do card abre o diálogo com a descrição completa.
- **CT-E2E-04:** menu Editar, descrição 2000, contador vermelho, salvar, toast de atualização.
- **CT-E2E-05:** cria descrição curta e confirma que o card **não** tem Ver mais.
- **CT-E2E-06:** no carrossel Minhas Sugestões, Ver mais expande e não abre detalhes.

### E2E negativo

- **CT-E2E-07:** título/produto/pilar preenchidos e descrição em branco; toast de obrigatórios; formulário permanece; listagem não ganha card.
- **CT-E2E-08:** `maxLength` 2000 — o 2001º caractere não entra; contador fica `2000/2000`.

## Massa necessária

Nenhuma massa adicional pendente de humano.

| Item | Origem | Status |
|------|--------|--------|
| E-mail `admin@certtus.com` | seed Prisma / `dev-login` | ok |
| Produto `Sistema Certtus` (id 1) | API `GET /produtos` | ok |
| Pilar `Produtividade` (id 2) / primeiro da lista na API | API `GET /pilaresGestao` | ok |
| Login | UI local (`VITE_HABILITAR_LOGIN_DEV`) + `POST /autenticacao/dev-login` | ok |

Variáveis em `.env.example`: `E2E_BASE_URL`, `E2E_API_BASE_URL`, `E2E_TEST_EMAIL`. Sem senha (login local é só e-mail).

## UI do produto

Somente `data-testid` (e `cChave` já previsto no rodapé do modal, para montar o testid). Ver `seletores.md`.

## Como rodar

API em `:8085`, web em `:8080`. No repo de testes:

```bash
copy .env.example .env.local
npm run test:e2e -- tests/e2e/specs/descricao-sugestao
```
