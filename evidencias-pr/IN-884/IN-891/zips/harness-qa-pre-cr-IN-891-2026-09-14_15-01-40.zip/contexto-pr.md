# Contexto — `descricao-sugestao`

> Produto: **Mural de Sugestões** (`mural`)  
> Jira project: **IN** (Inovação)  
> Bug pai: **IN-884** — "Adicionar recurso para visualização completa da Descrição." (status Teste QA)  
> Tarefa de teste: **IN-891** — "Teste da Limite 2000 chars + preview expandível da descrição (Mural API + Web) - DEV: IN-887 - CR: IN-889" (status Fazendo)  
> Dev: **IN-887** (Concluído - Aprovado) · CR: **IN-889** (Concluído - Aprovado)  
> PRs: [mural-api #4](https://github.com/CERTTUS/mural-api/pull/4) · [mural-web #4](https://github.com/CERTTUS/mural-web/pull/4)  
> Data: 2026-09-14  
> Plataforma: `web` (Playwright + TypeScript)

## Resumo da tarefa

Bug **IN-884**: não era possível pré-visualizar o conteúdo completo da descrição na listagem, e o limite da descrição precisava subir para **2000 caracteres** (antes: **1000** na API).

A correção (DEV IN-887, CR IN-889) cobre API + Web:

1. **API** — validação Joi de `descricao` passa a aceitar até 2000 caracteres (criar e atualizar).
2. **Web** — preview expandível nos cards (`Ver mais` / `Ver menos`) e contador `n/2000` no formulário de criar/editar.

**IN-891** é a subtarefa de teste automático dessa correção. Não existe `harness-handoff.json`. Catálogo `scripts/pre-cr/catalogo-modulos.json` está vazio (primeira tarefa do produto).

**CTs Jira existentes:** JQL `parent = IN-884 AND issuetype = "Cenarios de Teste"` retornou **vazio**. Não há subtarefas de cenários a reutilizar.

Links:

- https://certtus-team.atlassian.net/browse/IN-891
- https://certtus-team.atlassian.net/browse/IN-884
- https://github.com/CERTTUS/mural-api/pull/4
- https://github.com/CERTTUS/mural-web/pull/4

### PRs (abertas, base `develop`)

| Repo | PR | Branch | Título |
|------|----|--------|--------|
| mural-api | [#4](https://github.com/CERTTUS/mural-api/pull/4) | `fix/IN-884-visualizacao-descricao` | IN-884 - [Fix] Eleva limite da descrição para 2000 caracteres |
| mural-web | [#4](https://github.com/CERTTUS/mural-web/pull/4) | `fix/IN-884-visualizacao-descricao` | IN-884 - [Fix] Preview expandível da descrição e contador no formulário |

Deploy: as duas PRs devem ir juntas (API aceitando 2000 + UI com `maxLength`/preview).

## Arquivos / módulos envolvidos

### Front-end (`mural-web`)

- `src/constants/sugestao.ts` (**novo**) — `N_DESCRICAO_SUGESTAO_MAX = 2000`
- `src/components/DescricaoExpandivel.tsx` (**novo**) — preview com `line-clamp-2` (default), overflow via `scrollHeight > clientHeight + 1`, botões "Ver mais"/"Ver menos", `stopPropagation` no clique do botão
- `src/components/SuggestionCard.tsx` — listagem principal; usa `DescricaoExpandivel`; clique no card abre detalhes
- `src/components/FeaturedCards.tsx` — carrosséis (implementadas / minhas sugestões); mesma integração
- `src/components/ModalLateralSugestao.tsx` — criar/editar: `maxLength={2000}` + contador `{n}/2000` (vermelho no limite); payload com `descricao.trim()`
- Relacionados (sem alteração nesta PR, mas no fluxo de leitura completa):
  - `src/components/SuggestionDetailsDialog.tsx` — modal de detalhes exibe descrição **completa** (sem clamp)
  - `src/hooks/useApi.ts` — toasts de sucesso/erro em create/update
  - `src/services/api.ts` — `POST /sugestoes`, `PUT /sugestoes/:id`
  - `src/config/api.ts` — endpoints

### Back-end / API (`mural-api`)

- `src/constants/sugestao.ts` (**novo**) — `N_DESCRICAO_SUGESTAO_MAX = 2000`
- `src/controllers/Sugestao/CriarController.ts` — Joi `.trim().max(N_DESCRICAO_SUGESTAO_MAX).required()`
- `src/controllers/Sugestao/AtualizarController.ts` — mesma validação de descrição
- `src/rotas.ts` — `POST /sugestoes`, `PUT /sugestoes/:sugestaoId` (ambas com `usuarioAutenticadoValidar`)
- Persistência: Prisma `sugestoes.descricao` é `String`/`TEXT` — **sem limite no banco**; o teto é só a validação Joi

**Fora do escopo (não confundir):** comentários continuam com limite **500** (`SugestaoComentario` Criar/Atualizar). Título da sugestão permanece **2–100**.

## Fluxo principal

1. Usuário autenticado abre o modal lateral de nova sugestão (`ModalLateralSugestao`, `form-upsert-sugestao`).
2. Preenche título, descrição, produto e pilar. O textarea tem `maxLength=2000` e o contador mostra `{length}/2000`.
3. Submit faz `trim()` e chama `POST /sugestoes`. API valida Joi (trim + max 2000 + required). Sucesso: **201**.
4. A sugestão aparece na listagem (`SuggestionCard`) e, se aplicável, nos carrosséis (`FeaturedCards`).
5. Se a descrição **excede 2 linhas** no card: botão **Ver mais**. Clique no botão expande o texto **inline** e **não** abre o modal de detalhes (`stopPropagation`).
6. Com o texto expandido, o botão vira **Ver menos** (recolhe para 2 linhas).
7. Clique no card **fora** do botão abre o modal de detalhes (`SuggestionDetailsDialog`) com a descrição completa.
8. Edição: mesmo formulário em modo edição → `PUT /sugestoes/:sugestaoId`. Sucesso: **200**. A descrição longa também deve ser aceita até 2000.

## Regras de negócio

- Limite da descrição da **sugestão**: **2000 caracteres** (constante compartilhada API + Web). Limite anterior da API: **1000**.
- Descrição é **obrigatória**. Joi: string, `trim()`, `required`. Não há `.min()` além de vazio após trim.
- Mensagem de teto (API): `'A descrição deve ter no máximo 2000 caracteres.'`
- Mensagem vazia (API): `'A descrição não pode estar vazia.'` (também `'A descrição é obrigatória.'` se o campo faltar).
- Resposta de validação: HTTP **400** + `{ erro: true, mensagem: "<texto Joi>" }`.
- Criar com descrição válida: HTTP **201**. Atualizar: HTTP **200**.
- Rotas autenticadas (Bearer). Sem login, o formulário avisa `"Faça login para enviar uma sugestão."`
- No front, `maxLength` impede digitar o 2001º caractere; o caso 2001 é **teste de API** (bypass da UI).
- Contador: `{cDescricao.length}/{N_DESCRICAO_SUGESTAO_MAX}`. Classe `text-red-500` quando `length >= 2000`; caso contrário `text-muted-foreground`.
- Formulário inválido (descrição/título/produto/pilar vazios após trim): toast `"Preencha todos os campos obrigatórios."` — não dispara a API.
- Sucesso UI (toasts em `useApi`): `"Sugestão criada com sucesso!"` / `"Sugestão atualizada com sucesso!"` (ou `mensagem` da API, se vier).
- Preview nos cards: **2 linhas** (`line-clamp-2`). Botão só aparece se houver overflow visual **ou** se já estiver expandido.
- Clique em **Ver mais** / **Ver menos** não deve abrir o modal de detalhes.
- Descrição curta (cabe em ≤2 linhas): **sem** botão Ver mais.
- Modal de detalhes sempre mostra o texto completo (`whitespace-pre-line`), independente do preview do card.
- Joi aplica `trim()` **antes** do `.max(2000)`: o tamanho validado é o da string já aparada.

## Pontos de atenção para testes

- Validações:
  - API criar: `POST /sugestoes` — ~1800 chars → **201**; **2000** chars → **201**; **2001** → **400** com mensagem de limite; vazio/`"   "` → **400** `"A descrição não pode estar vazia."`; campo ausente → `"A descrição é obrigatória."`
  - API editar: `PUT /sugestoes/:sugestaoId` — mesmos limites; sucesso **200** até 2000 inclusive
  - UI: textarea não aceita mais que 2000 (`maxLength`); contador `1800/2000`, `2000/2000` (vermelho no teto)
  - UI: descrição em branco + demais campos preenchidos → toast de obrigatórios, sem POST
  - Comentário (500) e título (100) **não** mudaram — não usar esses limites nos CTs desta tarefa
- Mensagens / toasts:
  - API: `"A descrição deve ter no máximo 2000 caracteres."`
  - API: `"A descrição não pode estar vazia."` / `"A descrição é obrigatória."`
  - UI sucesso: `"Sugestão criada com sucesso!"` / `"Sugestão atualizada com sucesso!"`
  - UI erro de API: toast.error com `mensagem` do body 400 (ex.: limite)
  - UI: `"Faça login para enviar uma sugestão."` · `"Preencha todos os campos obrigatórios."`
- Permissões / menus:
  - Criar/editar exigem usuário autenticado
  - Editar no card: autor com situação pendente **ou** admin (menu ⋯ já existente; não é o foco do bug, mas necessário para o fluxo de PUT)
- Integrações:
  - Criar dispara e-mail de notificação no backend (`movimentacaoEmailNotificar`) — não bloquear E2E por e-mail
  - Front e API precisam estar na mesma versão do limite (2000); senão UI deixa passar o que a API antiga rejeita (1000)
- Condições de borda:
  - **2000 vs 2001** (API); **exato 2000** no contador (vermelho)
  - **trim**: espaços nas pontas não devem contar no teto Joi; só espaços → vazio
  - **Ver mais vs clique no card**: expandir inline sem abrir modal; clique fora do botão abre `SuggestionDetailsDialog` com texto completo
  - **Descrição curta vs longa**: curta (≤2 linhas) sem botão; longa (~1800 chars / overflow real) com Ver mais
  - Recolher: Ver menos volta ao clamp de 2 linhas e o botão permanece
  - **Criar vs editar**: mesmos limites nos dois verbos HTTP e no mesmo formulário (`lModoEdicao`)
  - Overflow do preview é **visual** (altura), não por contagem de caracteres — string longa em uma linha estreita vs texto curto que não quebra
  - Superfícies: listagem (`SuggestionCard`) **e** carrosséis (`FeaturedCards`)
  - `stopPropagation` também já existe em voto/menu; o novo risco é só o botão Ver mais
  - Autenticação obrigatória nas rotas de criar/atualizar
